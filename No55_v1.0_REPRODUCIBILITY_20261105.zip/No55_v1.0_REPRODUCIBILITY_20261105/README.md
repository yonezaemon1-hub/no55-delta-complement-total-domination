# No.55 - Exact Total-Domination Embeddings and Computational Hardness in δ-Complement Graphs

Ryutaro Yonezu - Independent Researcher | v1.0 | 5 November 2026

**Preprint. All rights reserved. Not human peer-reviewed. Novelty INCONCLUSIVE. Independent AI audit PASS within the audited scope (user-provided result).**

The paper gives exact total-domination embeddings and a direct Set Cover reduction proving NP-completeness for total domination in the δ-complement of a bipartite input. The output δ-complement need not be bipartite. Chen's original sum conjecture is neither proved nor refuted.

## Files

- No55_v1.0_PREPRINT_20261105.pdf: public manuscript.
- No55_v1.0_MANUSCRIPT_20261105.md and .tex: manuscript sources.
- frozen_v0.2/: complete unchanged audited package, including historical HOLD labels.
- original_archives/: original v0.1, v0.2 and Windows hotfix ZIPs.
- windows/: user-supplied original Windows transcript, separate v0.1.2 hotfix and literally extracted Set Cover helper.
- audit_records/: supplied final-check record.
- PUBLICATION_STATUS_20261105.md: current audit attribution and limits.
- PUBLICATION_DIFF_FROM_v02.patch: editorial manuscript changes.
- SHA256SUMS_REPRO.txt: all bundle files except itself.

## Reproduction

Use a disposable copy of frozen_v0.2/, since audit_atlas.py writes its evidence file. With Python 3.10+ and locally available NumPy, SciPy (milp), and NetworkX:

```text
python -B code/verify_no55.py --milp --output sample_recheck.json
python -B code/audit_atlas.py
```

The supplied Windows transcript records the original v0.1 ZIP run with No55_Run_Windows_v012.ps1 on 2026-11-05 14:11 JST: 16 MILP, 33 Atlas, 40 Set Cover and 11 composed cases PASS. It is not a v0.2/v1.0 Windows run. See PUBLICATION_STATUS_20261105.md before interpreting historical status files or these checks.

Formal publication was explicitly authorized by the author. Actual external publication and public file identity are recorded in the separate publication receipt. No human peer review or confirmed novelty is claimed.
