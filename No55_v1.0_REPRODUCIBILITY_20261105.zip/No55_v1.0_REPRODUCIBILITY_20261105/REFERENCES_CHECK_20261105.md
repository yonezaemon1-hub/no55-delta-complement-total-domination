# No.55 - Publication bibliography check (2026-11-05 JST)

Only public primary sources and the supplied audit records were used. This is a bibliography/scope check, not an exhaustive priority search.

- Pai et al. (2022): publisher search result confirms the five authors, title, Mathematics 10(8), 1203, and degree-class toggling definition. https://www.mdpi.com/2227-7390/10/8/1203 . Direct page fetch was rate limited during this workflow; public publisher search excerpts were available.
- Tangjai et al. (2026): publisher article/issue search confirms five authors, Mathematics 14(4), 734, and ordinary domination scope. https://www.mdpi.com/2227-7390/14/4/734 . Direct fetch rate limited; publisher search excerpts checked.
- Chen (2026): publisher search text confirms Pinhe Chen, Mathematics 14(11), 1797, equal-original-degree definition, k as the number of distinct degrees, and the proposed total-domination sum bound. https://www.mdpi.com/2227-7390/14/11/1797 . No complete full-text read is claimed.
- Karp (1972): Springer public chapter page confirms author, pp.85-103, 1972, DOI and editors Miller, Thatcher and Bohlinger. Added the third editor in the publication bibliography only. Full chapter not inspected. https://link.springer.com/chapter/10.1007/978-1-4684-2001-2_9
- Pfaff/Laskar/Hedetniemi (1983): the author's Clemson faculty vita lists Technical Report 428 (July 1983), confirming the bibliographic attribution. Full report not inspected and not a proof dependency. https://people.computing.clemson.edu/~hedet/vita.html
- Laskar et al. (1984): SIAM public article page confirms four authors, SIAM Journal on Algebraic Discrete Methods 5(3), pp.420-425; abstract concerns trees and undirected path graphs. https://epubs.siam.org/doi/10.1137/0605040 . Full text not inspected.
- Shalu/Kirubakaran (2025): Springer public page confirms authors, Journal of Combinatorial Optimization 50, article 44, and public abstract on bipartite subclasses. The page also lists the 1983 report among its references. https://link.springer.com/article/10.1007/s10878-025-01360-w . Full article not inspected.

REFERENCES PARTIAL; NOVELTY INCONCLUSIVE. No claim of an exhaustive search or full reading of inaccessible works.
