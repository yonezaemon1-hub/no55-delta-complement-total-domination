# No55 Windows PowerShell 5.1, fail-closed one-shot reproducibility audit.
# No network, no pip, no paid services, no changes to the frozen No55 v0.1 ZIP.
# Required: original No55 v0.1 ZIP in Downloads; local Python 3.10+, scipy, numpy, networkx.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$zipName = 'No55_v0.1_PRIOR_ART_AUDIT_HOLD_20261105.zip'
$folderName = 'No55_v0.1_PRIOR_ART_AUDIT_HOLD_20261105'
$expectedZipHash = '59cfc977ac12c7bcc199e23824381bc51410a9c74c6902cab1d13752727893e8'
$downloads = Join-Path $env:USERPROFILE 'Downloads'
$zip = Join-Path $downloads $zipName
$stamp = (Get-Date).ToString('yyyyMMdd_HHmmss_fff')
$runRoot = Join-Path $downloads ('No55_WINDOWS_REPRO_' + $stamp)
$sourceOuter = Join-Path $runRoot 'SOURCE_EXTRACT'
$source = Join-Path $sourceOuter $folderName
$work = Join-Path $runRoot 'WORK_COPY'
$log = Join-Path $runRoot 'No55_WINDOWS_LOG.txt'
$transcriptStarted = $false
New-Item -ItemType Directory -Path $runRoot -Force | Out-Null

function Assert-Hash([string]$path, [string]$expected, [string]$label) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing $label`: $path" }
    $found = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($found -ne $expected) { throw "SHA256 FAIL $label`: expected $expected got $found" }
    Write-Host "PASS SHA256 $label $found"
}

function Verify-Directory([string]$root, [switch]$AllowChangedAtlas) {
    $manifest = Join-Path $root 'SHA256SUMS.txt'
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw 'Missing SHA256SUMS.txt' }
    $lines = @(Get-Content -LiteralPath $manifest -Encoding UTF8)
    if ($lines.Count -ne 11) { throw "FAIL manifest count: $($lines.Count), expected 11" }
    $allowed = @('SHA256SUMS.txt')
    foreach ($line in $lines) {
        $matched = [regex]::Match($line, '^([0-9a-f]{64})  ([A-Za-z0-9_./-]+)$')
        if (-not $matched.Success) { throw "Malformed SHA256 line: $line" }
        $hash = $matched.Groups[1].Value
        $rel = $matched.Groups[2].Value
        if ($rel.Contains('..') -or $rel.StartsWith('/') -or $rel.Contains(':')) {
            throw "Unsafe manifest path: $rel"
        }
        $allowed += $rel
        if ($AllowChangedAtlas -and $rel -eq 'evidence/atlas_results.json') { continue }
        $path = Join-Path $root ($rel.Replace('/', '\'))
        $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $hash) { throw "FAIL file hash: $rel (expected $hash got $actual)" }
    }
    $found = @(Get-ChildItem -LiteralPath $root -File -Recurse | ForEach-Object {
        $_.FullName.Substring($root.Length + 1).Replace('\', '/')
    })
    $extra = @($found | Where-Object { $allowed -notcontains $_ })
    $missing = @($allowed | Where-Object { $found -notcontains $_ })
    if ($extra.Count -gt 0 -or $missing.Count -gt 0) {
        throw "Inventory FAIL extra=$($extra -join ',') missing=$($missing -join ',')"
    }
    Write-Host "PASS: manifest (11 hashes), exact inventory (12 files), allowChangedAtlas=$AllowChangedAtlas"
}

function Canonical-Json([string]$path) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing JSON: $path" }
    return (Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json | ConvertTo-Json -Depth 60 -Compress)
}

function Invoke-Python([string[]]$Arguments) {
    $all = @($script:PyPrefix) + @('-B') + $Arguments
    Write-Host ("RUN: " + $script:PyExe + ' ' + ($all -join ' '))
    & $script:PyExe @all
    if ($LASTEXITCODE -ne 0) { throw "Python FAIL exit=$LASTEXITCODE" }
}

try {
    Start-Transcript -LiteralPath $log -Force | Out-Null
    $transcriptStarted = $true
    Write-Host 'No55 Windows reproducibility audit v0.1.2: PowerShell native-argument hotfix; immutable source + disposable work copy'
    Write-Host "RUN DIRECTORY: $runRoot"
    # Browsers may append (1), (2), etc. Match by content hash, never by filename alone.
    $zipCandidates = @(Get-ChildItem -LiteralPath $downloads -Filter 'No55_v0.1_PRIOR_ART_AUDIT_HOLD_20261105*.zip' -File)
    $matchingZips = @($zipCandidates | Where-Object {
        (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -eq $expectedZipHash
    })
    if ($matchingZips.Count -lt 1) {
        throw "No SHA256-matching No55 v0.1 ZIP found in $downloads"
    }
    if (Test-Path -LiteralPath $zip -PathType Leaf) {
        if ((Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedZipHash) {
            $zip = $matchingZips[0].FullName
        }
    }
    else { $zip = $matchingZips[0].FullName }
    Write-Host "SOURCE ZIP: $zip"
    Assert-Hash $zip $expectedZipHash 'immutable original ZIP (before)'

    Add-Type -AssemblyName 'System.IO.Compression.FileSystem'
    $reader = [System.IO.Compression.ZipFile]::OpenRead($zip)
    try {
        $entries = @($reader.Entries | Where-Object { -not $_.FullName.EndsWith('/') })
        if ($entries.Count -ne 12) { throw "ZIP inventory FAIL: $($entries.Count) entries, expected 12" }
        $seen = @{}
        foreach ($e in $entries) {
            $name = $e.FullName
            if ($name -notmatch '^No55_v0\.1_PRIOR_ART_AUDIT_HOLD_20261105/[A-Za-z0-9_./-]+$') {
                throw "Unsafe ZIP member: $name"
            }
            if ($name.Contains('..') -or $seen.ContainsKey($name)) {
                throw "Traversal or duplicate ZIP member: $name"
            }
            $seen[$name] = $true
        }
        Write-Host 'PASS: ZIP member count and safe paths (12 members)'
    }
    finally { $reader.Dispose() }

    New-Item -ItemType Directory -Path $sourceOuter -Force | Out-Null
    Expand-Archive -LiteralPath $zip -DestinationPath $sourceOuter -Force
    if (-not (Test-Path -LiteralPath $source -PathType Container)) {
        throw "Expected extraction root missing: $source"
    }
    Verify-Directory $source

    Copy-Item -LiteralPath $source -Destination $work -Recurse
    Verify-Directory $work

    # v0.1.2: Only invoke the directly identified Python 3.10 interpreter.
    # Windows PowerShell 5.1 can strip double quotes from python -c arguments;
    # avoid the -c quoting problem by saving the probe as a disposable .py file.
    # Also do not concatenate multiple Get-Command results into one path.
    $script:PyExe = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python310\python.exe'
    $script:PyPrefix = @()
    if (-not (Test-Path -LiteralPath $script:PyExe -PathType Leaf)) {
        throw "FAIL-CLOSE: Python 3.10 executable missing at $($script:PyExe)"
    }
    $probePath = Join-Path $runRoot 'No55_Python_Preflight_v012.py'
    $preflightCode = @'
import sys
import numpy
import scipy
import networkx
from scipy.optimize import milp
if sys.version_info[:2] < (3, 10):
    raise RuntimeError('Python >=3.10 required')
print('READY', sys.version.split()[0], 'NumPy', numpy.__version__,
      'SciPy', scipy.__version__, 'NetworkX', networkx.__version__)
'@
    [System.IO.File]::WriteAllText($probePath, $preflightCode, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host "CHECK direct Python 3.10: $($script:PyExe)"
    $probeResult = @()
    $probeExit = 1
    $oldErrorAction = $ErrorActionPreference
    try {
        # Capture native stderr without turning a nonzero exit into a silent PASS.
        $ErrorActionPreference = 'Continue'
        $probeResult = @(& $script:PyExe '-B' $probePath 2>&1)
        $probeExit = $LASTEXITCODE
    }
    catch {
        $probeResult += $_.Exception.Message
        $probeExit = 1
    }
    finally { $ErrorActionPreference = $oldErrorAction }
    $probeText = (($probeResult | Out-String).Trim())
    Write-Host "PYTHON PROBE exit=$probeExit`: $probeText"
    if ($probeExit -ne 0 -or $probeText -notmatch 'READY') {
        throw 'FAIL-CLOSE: Direct Python 3.10 import probe failed; see PYTHON PROBE above.'
    }
    Write-Host 'PASS: Python 3.10 NumPy/SciPy(milp)/NetworkX preflight'

    $verifyPath = Join-Path $work 'code\verify_no55.py'
    $atlasPath = Join-Path $work 'code\audit_atlas.py'
    $sampleOutput = Join-Path $runRoot 'sample_results_WINDOWS.json'
    Invoke-Python -Arguments @($verifyPath, '--milp', '--output', $sampleOutput)
    $sample = Get-Content -LiteralPath $sampleOutput -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($sample.status -ne 'PASS' -or $sample.case_count -ne 16 -or -not $sample.milp) {
        throw 'FAIL sample output: expected 16 cases all with MILP'
    }
    $frozenSample = Get-Content -LiteralPath (Join-Path $source 'evidence\sample_results.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if (($sample.cases | ConvertTo-Json -Depth 60 -Compress) -cne ($frozenSample.cases | ConvertTo-Json -Depth 60 -Compress)) {
        throw 'FAIL: sample cases differ from frozen evidence'
    }
    Write-Host 'PASS: 16 MILP tests match frozen sample case data'

    # audit_atlas.py rewrites evidence/atlas_results.json; run ONLY in disposable WORK_COPY.
    Invoke-Python -Arguments @($atlasPath)
    $newAtlas = Join-Path $work 'evidence\atlas_results.json'
    $frozenAtlas = Join-Path $source 'evidence\atlas_results.json'
    if ((Canonical-Json $newAtlas) -cne (Canonical-Json $frozenAtlas)) {
        throw 'FAIL: atlas JSON differs semantically from frozen evidence'
    }
    $atlasData = Get-Content -LiteralPath $newAtlas -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($atlasData.status -ne 'PASS' -or $atlasData.count -ne 33) {
        throw 'FAIL: expected 33 Atlas cases'
    }
    Copy-Item -LiteralPath $newAtlas -Destination (Join-Path $runRoot 'atlas_results_WINDOWS.json')
    Write-Host 'PASS: 33 Atlas MILP tests and exact semantic JSON match'

    $setCoverCode = @'
"""Deterministic Set Cover -> bipartite total domination check, local only.
Generated by No55_Run_Windows_v012.ps1 outside the immutable research bundle.
"""
import itertools
import json
import random
import sys
from pathlib import Path

code_dir = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(code_dir))
from no55_core import make_graph, construct, delta_complement
from verify_no55 import exact_total_dom_milp


def min_cover(number_of_sets, number_of_elements, membership):
    for size in range(1, number_of_sets + 1):
        for subset in itertools.combinations(range(number_of_sets), size):
            if all(any((i, j) in membership for i in subset)
                   for j in range(number_of_elements)):
                return size
    raise AssertionError('Generated Set Cover instance was infeasible')


def bipartite_reduction(number_of_sets, number_of_elements, membership):
    # X = {s_i, p, r}; Y = {e_j, z, q}.
    p = number_of_sets + number_of_elements
    r = p + 1
    z = p + 2
    q = p + 3
    edges = [(i, z) for i in range(number_of_sets)]
    edges += [(i, number_of_sets + j) for (i, j) in membership]
    edges += [(p, z), (p, q), (r, z)]
    return make_graph(number_of_sets + number_of_elements + 4, edges)


def main():
    rng = random.Random(55012026)
    count_f = 0
    records = []
    for trial in range(40):
        ns = rng.randint(1, 4)
        ne = rng.randint(1, 4)
        members = {(rng.randrange(ns), j) for j in range(ne)}
        for i in range(ns):
            for j in range(ne):
                if rng.random() < 0.38:
                    members.add((i, j))
        tau = min_cover(ns, ne, members)
        B = bipartite_reduction(ns, ne, members)
        gamma_B = exact_total_dom_milp(B)
        if gamma_B != tau + 2:
            raise AssertionError((trial, gamma_B, tau + 2))
        record = {'trial': trial, 'sets': ns, 'elements': ne,
                  'vertices_B': len(B), 'tau': tau, 'gamma_B': gamma_B}
        if len(B) <= 8 and count_f < 11:
            F, _ = construct(B)
            H = delta_complement(F)
            gamma_H = exact_total_dom_milp(H)
            expected = 2 * len(B) + tau + 2
            if gamma_H != expected:
                raise AssertionError((trial, gamma_H, expected))
            record['gamma_Fdelta'] = gamma_H
            count_f += 1
        records.append(record)
        print(f"PASS SetCover trial={trial+1:02d} B={len(B)} tau={tau} "
              f"gammaB={gamma_B} Fdelta={'YES' if 'gamma_Fdelta' in record else 'SKIP'}",
              flush=True)
    if count_f < 1:
        raise AssertionError('No composed F(B) tests performed')
    report = {'status': 'PASS', 'setcover_cases': 40,
              'composed_F_cases': count_f, 'seed': 55012026, 'cases': records}
    Path(sys.argv[2]).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(f'PASS: 40 Set Cover reductions and {count_f} composed F(B) reductions')


if __name__ == '__main__':
    main()
'@
    $setCoverPath = Join-Path $runRoot 'No55_SetCover_Windows_Audit_v01.py'
    [System.IO.File]::WriteAllText($setCoverPath, $setCoverCode, (New-Object System.Text.UTF8Encoding($false)))
    $setCoverOutput = Join-Path $runRoot 'setcover_results_WINDOWS.json'
    Invoke-Python -Arguments @($setCoverPath, (Join-Path $work 'code'), $setCoverOutput)
    $sc = Get-Content -LiteralPath $setCoverOutput -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($sc.status -ne 'PASS' -or $sc.setcover_cases -ne 40 -or $sc.composed_F_cases -lt 1) {
        throw 'FAIL: Set Cover addendum verification summary'
    }
    Write-Host "PASS: Set Cover reduction 40 cases, composed F(B) $($sc.composed_F_cases) cases"

    Verify-Directory $source
    Verify-Directory $work -AllowChangedAtlas
    Assert-Hash $zip $expectedZipHash 'immutable original ZIP (after)'
    'PASS: Windows local reproduction; 16 sample MILP, 33 Atlas MILP, 40 Set Cover MILP, composed F(B); SHA256 verified. NOVELTY INCONCLUSIVE; RELEASE HOLD.' | Set-Content -LiteralPath (Join-Path $runRoot 'STATUS_WINDOWS.txt') -Encoding UTF8
    Write-Host 'PASS: Windows reproduction checks completed.'
    Write-Host 'NOVELTY INCONCLUSIVE; RELEASE HOLD; Windows reproduction is not a new originality or proof audit.'
    Write-Host "LOG: $log"
    Write-Host "OUTPUTS: $runRoot"
}
catch {
    $message = $_.Exception.Message
    Write-Host "FAIL-CLOSE: $message"
    ('FAIL-CLOSE: ' + $message) | Set-Content -LiteralPath (Join-Path $runRoot 'STATUS_WINDOWS.txt') -Encoding UTF8
    throw
}
finally {
    if ($transcriptStarted) { Stop-Transcript | Out-Null }
    Write-Host "LOG: $log"
    Write-Host "OUTPUTS: $runRoot"
}
