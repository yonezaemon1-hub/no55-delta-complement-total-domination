---
title: "Exact Total-Domination Embeddings and Computational Hardness in δ-Complement Graphs"
author: "Ryutaro Yonezu — Independent Researcher"
date: "5 November 2026 · No.55 · v1.0 · Preprint"
---

**All rights reserved. Not human peer-reviewed. Novelty: INCONCLUSIVE. Independent AI audit: PASS within the audited scope (reported; not human peer review).**


## Abstract

The δ-complement of a graph toggles adjacency within each class of vertices of equal *original* degree, leaving cross-class adjacency unchanged. We give a polynomial-time transformation \(F\) from any isolate-free finite simple graph \(Q\) on \(m\) vertices such that

\[
\gamma_t(F(Q))=3m,\qquad
\gamma_t(F(Q)_\delta)=2m+\gamma_t(Q),\qquad
k(F(Q))=m+1.
\]

Here \(\gamma_t\) is the total domination number and \(k\) the number of distinct vertex degrees. The transformation preserves bipartiteness and, for a tree input, acyclicity and connectedness. Each non-leaf degree class in \(F(Q)\) induces a three-vertex path. As a consequence, the decision problem for total domination in the δ-complement of a **bipartite input** graph is NP-complete. We prove this via an explicit, independently auditable Set Cover reduction, rather than relying on an inaccessible historical hardness proof. A family of trees also shows that the separate auxiliary inequality \(\gamma_t(T_\delta)\le2k(T)\) can fail by an unbounded amount. None of these results proves or disproves Chen's distinct conjecture on the *sum* \(\gamma_t(G)+\gamma_t(G_\delta)\). Independent AI and Windows reproducibility checks have been reported; originality and human peer review remain unresolved.

## 1. Introduction and previous work

Pai et al. [1] introduced the δ-complement. Tangjai et al. [2] investigated bounds on the **ordinary** domination number under this operation, and Chen [3] studied Roman and total domination and posed a Nordhaus–Gaddum-type total-domination conjecture. We do not claim priority for the δ-complement itself, the NP-completeness of Set Cover, or NP-hardness of total domination on ordinary bipartite graphs. Our subject is the exact embedding of the total-domination number into a δ-complement, together with an explicitly composed complexity reduction. No theorem with this exact construction was located in the references examined; this does **not** constitute an exhaustive novelty determination.

All graphs in the paper are finite, simple and undirected. A *total dominating set* (TDS) of a graph \(G\) is a vertex set \(S\) such that every vertex has a neighbor in \(S\), including the vertices of \(S\) themselves. For graphs without isolated vertices, \(\gamma_t(G)\) denotes the minimum size of such a set. The δ-complement \(G_\delta\) retains the vertex set and changes adjacency as follows: for distinct \(u,v\), it toggles the edge \(uv\) if \(\deg_G(u)=\deg_G(v)\), and otherwise leaves the edge unchanged. All degrees are computed in \(G\), not in the transformed graph. Write \(k(G)\) for the number of *distinct* values in the degree sequence; this matches Chen's convention [3].

## 2. Degree-class gadget construction

Let \(Q\) have no isolated vertices, with \(m=|V(Q)|\ge2\). Choose pairwise distinct integers \(d_v\) satisfying

\[
d_v\ge\max\{3,\deg_Q(v)+2\}\qquad(v\in V(Q)).
\]

For each \(v\), create the triple \(x_v,c_v,y_v\), add edges \(x_vc_v\) and \(c_vy_v\), and for each edge \(vw\in E(Q)\), add \(c_vc_w\). Attach \(d_v-1\) new private leaves to \(x_v\), \(d_v-1\) to \(y_v\), and \(d_v-2-\deg_Q(v)\) to \(c_v\). Call the resulting graph \(F(Q)\).

All three non-leaf vertices in the \(v\)-gadget have degree \(d_v\); its degree class induces exactly \(P_3=x_v-c_v-y_v\). All additional vertices have degree 1, so \(k(F(Q))=m+1\). A polynomially bounded choice, for example enumerating the vertices and taking \(d_{v_i}=m+2+i\) for \(0\le i<m\), produces at most \(O(m^2)\) vertices. The transformation preserves bipartiteness. If \(Q\) is a tree, \(F(Q)\) is a tree.

**Theorem 1 (exact embedding).** For each isolate-free \(Q\) of order \(m\ge2\),

\[
\boxed{\gamma_t(F(Q))=3m,\qquad
\gamma_t(F(Q)_\delta)=2m+\gamma_t(Q).}
\]

### 2.1. An elementary open-neighborhood lemma

**Lemma 1.** For isolate-free \(Q\), any \(C\subseteq V(Q)\), and \(U=V(Q)\setminus N_Q(C)\), where \(N_Q(C)\) is the *open* neighborhood,

\[
\gamma_t(Q)\le |C|+|U|.
\]

*Proof.* For each \(u\in U\), choose any neighbor \(f(u)\) in \(Q\). Then \(C\cup\{f(u):u\in U\}\) totally dominates \(Q\) because vertices in \(N_Q(C)\) have a neighbor in \(C\), and those in \(U\) have their chosen neighbor. Its size is at most \(|C|+|U|\). ∎

### 2.2. Total domination of the original graph

Each \(x_v\) and \(y_v\) is mandatory in every TDS of \(F(Q)\) because each has private leaves. These two vertices are not adjacent in \(F(Q)\). To dominate both, one must additionally choose \(c_v\), or at least one private leaf adjacent to *each* of \(x_v\) and \(y_v\). Consequently at least three vertices are selected for each gadget; the gadgets are vertex-disjoint. Thus \(\gamma_t(F(Q))\ge3m\). Selecting every \(c_v,x_v,y_v\) gives a TDS of size \(3m\), hence equality. This argument does not assume that \(c_v\) itself has a private leaf.

### 2.3. Total domination of the δ-complement

Let \(H=F(Q)_\delta\). The degree-1 leaves form one clique in \(H\). In each non-leaf degree class, \(x_vy_v\) becomes an edge, while \(c_v\) is nonadjacent to \(x_v,y_v\). Edges between centers of different degrees remain precisely the edges of \(Q\). Original parent–leaf edges are unchanged.

For each \(v\), let \(R_v\) contain \(x_v,y_v\) and their private leaves. In \(H\), the two vertices \(x_v,y_v\) have no common neighbor; to dominate both, a TDS must select at least two vertices from \(R_v\). The \(R_v\) are disjoint. Let \(C=\{v:c_v\text{ is selected}\}\) and \(U=V(Q)\setminus N_Q(C)\). Any \(c_v\) with \(v\in U\) can then be dominated only by one of its *own* private leaves. These leaves lie outside every \(R_w\) and are disjoint for different \(v\). Therefore

\[
|S|\ge2m+|C|+|U|\ge 2m+\gamma_t(Q)
\]

by Lemma 1. If a center lacks a private leaf, it simply cannot belong to \(U\) for a valid TDS; the inequality remains correct.

Conversely, fix \(v_0\in V(Q)\). For its gadget, select one private leaf of \(x_{v_0}\) and one private leaf of \(y_{v_0}\). For each \(v\ne v_0\), select \(x_v,y_v\). The two selected leaves dominate one another and all other leaves in their global clique; they also dominate \(x_{v_0},y_{v_0}\). Each remaining selected pair \(x_v,y_v\) dominates itself in \(H\). Finally choose the centers corresponding to any minimum TDS of \(Q\). All centers are then dominated through the preserved center edges. This yields a TDS in \(H\) of size \(2m+\gamma_t(Q)\), giving the reverse bound and proving Theorem 1. ∎

## 3. Direct Set Cover reduction and NP-completeness

The following proof is fully included rather than delegated to a claim about bipartite TDS. Karp [4] is cited for the classical NP-completeness of Set Cover; the historical bipartite TDS literature [5–7] supplies context only, not a dependency.

An instance of **Set Cover** has ground set \(E=\{e_1,\ldots,e_n\}\), candidate subsets \(S_1,\ldots,S_s\subseteq E\), and threshold \(t\). We may restrict to nonempty ground sets for which every element belongs to at least one candidate subset; otherwise an uncovered element makes the instance an immediate NO, and trivial empty-ground instances can be handled separately. Let \(\tau\) denote the minimum number of sets covering \(E\).

Construct a graph \(B\) with bipartition

\[
X=\{s_1,\ldots,s_s,p,r\},\qquad
Y=\{e_1,\ldots,e_n,z,q\}.
\]

Add the following and **only** the following edges:

1. \(s_i e_j\) precisely when \(e_j\in S_i\);
2. \(s_i z\) for every candidate set \(S_i\);
3. \(pz,pq,rz\).

Every vertex of \(B\) has a neighbor, by the coverage assumption. Because \(q\) has sole neighbor \(p\), every TDS of \(B\) contains \(p\). Likewise \(r\) forces \(z\). The only neighbors of \(e_j\) are those set vertices \(s_i\) with \(e_j\in S_i\), so the selected set vertices must form a cover. Therefore \(\gamma_t(B)\ge\tau+2\).

Conversely, take \(p,z\) and the \(s_i\) corresponding to any minimum cover. The vertices \(p,z\) dominate one another; \(p\) dominates \(q\); \(z\) dominates \(r\) and every \(s_i\); and the selected \(s_i\) dominate all \(e_j\). Thus the selected vertices constitute a TDS of size \(\tau+2\), establishing

\[
\boxed{\gamma_t(B)=\tau+2.}
\]

Now apply Theorem 1 to the **bipartite isolate-free** graph \(B\):

\[
\boxed{\gamma_t(F(B)_\delta)=2|V(B)|+\tau+2.}
\]

The many-one mapping for the decision problem is

\[
(E,\{S_i\},t)\ \longmapsto\ (F(B),\ 2|V(B)|+t+2).
\]

The transformed **input graph** \(F(B)\) is bipartite, has polynomial size and has isolate-free δ-complement. Therefore the Set Cover instance is a YES instance if and only if the δ-complement of this bipartite input graph has a TDS of size at most the displayed threshold. Instances with uncovered elements may be sent to a fixed NO instance, e.g. \((F(K_2),1)\), without affecting polynomiality. Membership in NP follows because degrees, δ-complement adjacency, and the total-domination property of a proposed set are computable in polynomial time.

**Corollary 2 (NP-completeness).** The decision problem

> Given a bipartite input graph \(G\) such that \(G_\delta\) has no isolated vertices, and an integer \(b\), does \(\gamma_t(G_\delta)\le b\)?

is NP-complete. **The output graph \(G_\delta\) need not itself be bipartite.** The proof does not rely on obtaining the full text of the historical 1983 technical report. ∎

## 4. A tree family and the scope of Chen's conjecture

Taking \(Q=P_m\), \(m\ge2\), makes \(T_m=F(P_m)\) a tree, with \(k(T_m)=m+1\). From Theorem 1,

\[
\gamma_t((T_m)_\delta)-2k(T_m)=\gamma_t(P_m)-2.
\]

Since \(\gamma_t(P_m)\) tends to infinity with \(m\), the gap is unbounded. This refutes **only** the stronger auxiliary statement \(\gamma_t(T_\delta)\le 2k(T)\); it is **not** a counterexample to Chen's distinct proposed bound [3]

\[
\gamma_t(G)+\gamma_t(G_\delta)\le |V(G)|+2k(G),
\]

whose conjecture assumes both graphs have no isolated vertices. The original conjecture remains UNPROVEN in this work.

## 5. Reproducibility, audit boundaries and novelty

The frozen v0.1 implementation `frozen_v0.2/code/no55_core.py` constructs \(F(Q)\) and its δ-complement. `frozen_v0.2/code/verify_no55.py --milp` tests 16 designed examples and `frozen_v0.2/code/audit_atlas.py` tests 33 isolate-free Atlas graphs of orders 2–5. The seven frozen proof, code, evidence and run-script files are byte-identical to the audited v0.1 package. Independent AI audit PASS is a user-provided result, including the v0.2 documentation-only differential audit; it is not a new independent audit performed during publication. The manuscript is the primary public proof. The historical `PROOF_AUDIT_EN.md` label "external review NOT DONE" refers to its v0.1 creation date. The original `STATUS.txt` and `AUDIT_STATUS_v02_JA.md` retain obsolete v0.2 differential-audit and release labels as historical records. See `PUBLICATION_STATUS_20261105.md` for the current provenance.

The user supplied the original Windows PowerShell transcript, preserved without editing as `windows/No55_WINDOWS_LOG.txt`. It records Windows 10 / PowerShell 5.1 / Python 3.10.11 / NumPy 2.2.6 / SciPy 1.15.3 / NetworkX 3.4.2, on 5 November 2026 at 14:11 JST. It reports 16 MILP cases, 33 Atlas cases, 40 Set Cover cases and 11 composed cases PASS, with the original v0.1 ZIP SHA256 identical before and after execution. This is reproduction of the original v0.1 package using the separate `No55_Run_Windows_v012.ps1` hotfix, not Windows execution of v0.2 or v1.0. The hotfix is distinct from the frozen `run_windows.ps1`. Its Set Cover helper is included by literal extraction from that hotfix; the Windows-generated result JSON files were not supplied and are not claimed to be included.

These checks do not constitute formal verification, human peer review or verification of priority. The exact embedding and NP-completeness statements have **no confirmed directly identical predecessor in the sources checked**, but the literature search is incomplete. **NOVELTY INCONCLUSIVE.** Formal publication of this v1.0 preprint was explicitly authorized by the author on 5 November 2026. Publication does not resolve priority, novelty, or human peer review.

## References

[1] A. Pai, H. A. Rao, S. D'Souza, P. G. Bhat, and S. Upadhyay, “δ-Complement of a Graph,” *Mathematics* **10**(8), 1203 (2022). https://doi.org/10.3390/math10081203

[2] W. Tangjai, C. Darayon, P. Vichitkunakorn, R. Maungchang, and W. Pho-on, “Bounds on the Domination Numbers of δ-Complement Graphs,” *Mathematics* **14**(4), 734 (2026). https://doi.org/10.3390/math14040734

[3] P. Chen, “Refined Nordhaus–Gaddum-Type Bounds for Roman and Total Domination on δ-Complement Graphs,” *Mathematics* **14**(11), 1797 (2026). https://doi.org/10.3390/math14111797

[4] R. M. Karp, “Reducibility Among Combinatorial Problems,” in *Complexity of Computer Computations*, R. E. Miller, J. W. Thatcher, and J. D. Bohlinger (eds.), Plenum Press, pp. 85–103 (1972). https://doi.org/10.1007/978-1-4684-2001-2_9

[5] J. Pfaff, R. Laskar, and S. T. Hedetniemi, “NP-Completeness of Total and Connected Domination, and Irredundance for Bipartite Graphs,” Technical Report No. 428, Department of Mathematical Sciences, Clemson University (1983). **Bibliographic cross-references checked; primary full text not inspected. Not used as a proof dependency.**

[6] R. Laskar, J. Pfaff, S. M. Hedetniemi, and S. T. Hedetniemi, “On the Algorithmic Complexity of Total Domination,” *SIAM Journal on Algebraic Discrete Methods* **5**(3), 420–425 (1984). https://doi.org/10.1137/0605040. Its public abstract discusses undirected path graphs; it is not cited as an independent proof of the bipartite case.

[7] M. A. Shalu and V. K. Kirubakaran, “Total Domination and Open Packing in Some Subclasses of Bipartite Graphs,” *Journal of Combinatorial Optimization* **50**, article 44 (2025). https://doi.org/10.1007/s10878-025-01360-w. Context for the known hardness of ordinary bipartite TDS, not a proof dependency here.
