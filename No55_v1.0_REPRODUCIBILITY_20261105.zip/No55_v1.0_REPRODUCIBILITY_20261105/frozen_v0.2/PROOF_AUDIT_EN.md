# No.55 v0.1: proof audit (internal; external review NOT DONE)

Author: Ryutaro Yonezu — Independent Researcher  
Date: 2026-11-05. NOVELTY INCONCLUSIVE. RELEASE HOLD.

## 1. Definitions

All graphs are finite, simple and undirected. A total dominating set (TDS) `S` of a graph `H` meets the open neighborhood of every vertex, including members of `S`. `gamma_t(H)` is the minimum cardinality of such a set when `H` has no isolated vertices.

The delta-complement `G_delta` has the same vertices as `G`; an edge `uv` is toggled if `deg_G(u)=deg_G(v)` and is unchanged otherwise. Degrees are always evaluated in the ORIGINAL graph `G`, not recomputed during toggling.

Let `Q` be isolate-free and `m=|V(Q)| >= 2`. For each vertex `v`, choose pairwise distinct integers `d_v >= deg_Q(v)+2`, with `d_v >= 3`. Define `F=F(Q)` with a triple `c_v,x_v,y_v` and edges `c_v x_v` and `c_v y_v`. Add edges `c_v c_w` for each `vw` of Q. Attach `d_v-1` private leaves to each of `x_v,y_v` and `d_v-2-deg_Q(v)` private leaves to `c_v`. Counts are nonnegative. All newly attached leaves are distinct and have degree 1.

Then `deg_F(c_v)=deg_F(x_v)=deg_F(y_v)=d_v`, the `d_v`-degree induced graph is exactly `P3 = x_v-c_v-y_v`, and the degree-one vertices form the only other degree class. Thus `k(F)=m+1`. The number of vertices is `3m + sum_v (3d_v - 4 - deg_Q(v))`, which is O(m^2) under the deterministic choice of the code. F is bipartite when Q is bipartite; F is a tree when Q is a tree.

## 2. Central elementary lemma

**Lemma.** If Q has no isolated vertices, C is any subset of V(Q), and `U = V(Q) \ N_Q(C)` (open neighborhood), then `gamma_t(Q) <= |C| + |U|`.

**Proof.** For each `u in U`, select one arbitrary neighbor `f(u)` in Q, which exists because Q is isolate-free. Then `C union {f(u):u in U}` is a total dominating set: every vertex in `N_Q(C)` has a selected neighbor from C; each other vertex u has selected neighbor f(u). Its size is at most `|C|+|U|`. QED.

## 3. Exact value on the original graph F

**Proposition.** `gamma_t(F)=3m`.

**Lower bound.** Each x_v and y_v is forced into every TDS because each has at least one degree-one neighbor. In the ORIGINAL F, x_v and y_v are nonadjacent and have as neighbors only c_v and their respective private leaves. Hence, after selecting x_v and y_v, in order to dominate both x_v and y_v we must also choose c_v (one additional vertex) OR choose at least one private leaf of EACH of x_v and y_v (two additional vertices). These choices are vertex-disjoint for different v. Therefore each gadget contributes at least three vertices, so every TDS has size >=3m. **This step is essential even when c_v has zero private leaves; one must not claim c_v is always forced.**

**Upper bound.** Select all 3m vertices c_v,x_v,y_v. Every selected vertex has a selected neighbor in the same P3, and every attached leaf is adjacent to its selected parent. The set is a TDS; hence equality. QED.

## 4. Exact value on the delta-complement

Let H=F_delta. In H, the degree-one leaves form a clique; x_v and y_v are adjacent to one another but neither is adjacent to c_v. All edges c_v-c_w follow Q, and each c_v retains adjacency to its own private c_v-leaves. For x_v,y_v, the only possible H-neighbors are each other and their respective private leaves. (Their neighbors outside the degree class in F are only their private leaves, and edges between different degree classes are preserved.)

**Theorem.** `gamma_t(H)=2m+gamma_t(Q)`.

**Lower bound.** The two vertices x_v,y_v have no common neighbor in H. To dominate both, every TDS S must select at least two vertices from the disjoint local region `R_v={x_v,y_v} union L(x_v) union L(y_v)`; one selected vertex cannot dominate both. These m regions do not intersect; they force at least 2m selections.

Let `C={v: c_v in S}`. Put `U=V(Q) \ N_Q(C)`. Each center c_v with v in U has NO selected center neighbor in H, and it has no H-neighbor among x_v,y_v or among any other region R_w. The only remaining possible selected neighbors are leaves private to c_v; therefore S must contain at least one such leaf for every v in U. Such leaves are disjoint from all R_w and from selected centers, and private to distinct v. Hence `|S| >= 2m+|C|+|U| >= 2m+gamma_t(Q)` by the lemma. If no private c_v-leaf exists for some v in U, such S cannot exist, reinforcing the inequality.

**Upper bound.** Pick a vertex v0 of Q. In R_v0 select one private leaf of x_v0 and one private leaf of y_v0; these two chosen leaves dominate each other in the global leaf clique and dominate x_v0 and y_v0 respectively. For every other v, select x_v and y_v, which are adjacent in H and dominate one another. All unselected leaves are dominated by either chosen leaf of v0 because all leaves form a clique. Finally select the centers c_v for a minimum TDS of Q; all centers (selected or not) have a selected center neighbor in H, by the definition of TDS in Q. Every vertex in H is now dominated. The set has exactly `2m+gamma_t(Q)` vertices, proving the upper bound. QED.

All selections used above are possible because each x_v, y_v has at least two private leaves under d_v>=3, and because Q is isolate-free. Therefore F_delta has no isolates.

## 5. Complexity consequence

Consider the decision problem D-TDS: given a (bipartite) graph G and integer t, decide whether `gamma_t(G_delta) <= t`, with G_delta isolate-free on promised inputs. The input Q to a standard TDS decision problem can be assumed bipartite and isolate-free; bipartite TDS is NP-complete (e.g. Shalu & Kirubakaran 2025, DOI 10.1007/s10878-025-01360-w). Map

`(Q,t) -> (F(Q), 2m+t)`.

The construction uses O(m^2) vertices, computable in polynomial time, and preserves bipartiteness from Q to F(Q). By Section 4, `gamma_t(Q) <= t` iff `gamma_t(F(Q)_delta) <= 2m+t`. A candidate total dominating set for G_delta can be checked in polynomial time, so D-TDS is in NP and NP-hard, hence NP-complete on bipartite INPUT graphs G. If an NP-hardness source input has an isolated vertex, this is a trivial NO instance and can be mapped to a fixed NO instance (e.g. F(K2), threshold 1).

**Scope:** The input graph is bipartite; its delta-complement need not be bipartite. We do NOT claim NP-hardness of TDS on the class of bipartite delta-complements themselves. G_delta has a clique of degree-one leaves.

## 6. Infinite family invalidating the *stronger auxiliary bound*

For Q=P_m, m>=2, F(Q) is a tree and has k=m+1 distinct degrees. By the theorem,

`gamma_t(F(P_m)_delta) - 2k(F(P_m)) = gamma_t(P_m)-2`.

The total domination number of paths grows without bound; thus the right-hand side tends to infinity. For m=5, gamma_t(P5)=3, so it is +1. This invalidates the earlier auxiliary conjecture `gamma_t(T_delta) <= 2k(T)` for all trees T. It **does not** contradict Chen's original conjecture on `gamma_t(T)+gamma_t(T_delta) <= |V(T)|+2k(T)`.

For the deterministic minimum-degree assignment used by the supplied code for Q=P_m, `|V(F(P_m))| = 3m(m+3)/2 + 2` (m>=2). Computational checks include m=2..8.

## 7. Audit boundary

- Mathematical proof: internal reasoning and manuscript-ready argument; NOT checked by another AI or a human referee.
- Numerical verification: independent SciPy/HiGHS exact MILP for 16 designed cases and all 33 isolate-free graph-atlas classes of orders 2..5; in addition, a dependency-free exhaustive subset check for the 17-vertex P2 example. See evidence JSON.
- Novelty: INCONCLUSIVE; search did not find the same exact construction in the sources reviewed, but no exhaustive priority or patent analysis was performed.
- Discarded earlier argument: the claimed classwise budget theorem and universal `gamma_t(T_delta) <=2k(T)` were not sound. They are **not** dependencies of this theorem.
- Chen Conjecture 4: UNPROVEN.
