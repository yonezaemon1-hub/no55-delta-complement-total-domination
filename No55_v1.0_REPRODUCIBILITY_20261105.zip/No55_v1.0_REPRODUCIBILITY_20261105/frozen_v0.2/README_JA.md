# No.55 v0.2 — Set Cover還元を本文統合した内部監査パッケージ

- **著者:** Ryutaro Yonezu — Independent Researcher
- **日付:** 2026-11-05
- **主題:** Exact Total-Domination Embeddings and Computational Hardness in δ-Complement Graphs
- **ライセンス:** All rights reserved
- **公開:** HOLD（GitHub/Zenodoへの公開許可なし）
- **新規性:** INCONCLUSIVE（直接一致未発見だが網羅性不十分）
- **人間査読:** 未実施

## 今回の作業範囲（ユーザー選択の①）

**v0.2は文書のみの改訂。** v0.1で外部AI監査を受け、Windows実機再現がPASSした数学・プログラム・証拠データを変更していない。

1. `MANUSCRIPT_DRAFT_EN.md` にSet Cover→二部TDSの**完全な還元証明**、Fとの合成、NP所属、適用範囲を統合。
2. 原稿中の主定理・補題も独立して読めるよう整理。ただし数学上の新主張や変更はない。
3. 1983年技術報告を証明の依存から外し、Karp (1972) を主要典拠にし、Chen・Pai・Tangjai・Laskarほか・Shalu–Kirubakaranを明示。
4. `PRIOR_ART_REPORT_JA.md` と `STATUS.txt` を現在の確認状況へ更新。
5. `AUDIT_STATUS_v02_JA.md` に監査状況と限界を記録、`CHANGELOG_v02.md` に凍結差分を記録。

## 正確な主張

`Q` は孤立点なしの有限単純グラフ、`m=|V(Q)|>=2`。

- `gamma_t(F(Q))=3m`
- `gamma_t(F(Q)_delta)=2m+gamma_t(Q)`
- `k(F(Q))=m+1`
- `Q` が二部なら `F(Q)` は二部、`Q` が木なら `F(Q)` は木
- Set Coverからの直接還元を合成すると、**二部入力グラフ**のδ-TDS判定はNP完全
- 木で `gamma_t(T_delta)-2k(T)` の無限超過が可能。ただし**Chenの元の和の予想とは異なる**

## ファイル

- `MANUSCRIPT_DRAFT_EN.md`：v0.2の完全な英語原稿（主定理とSet Cover還元を本文に統合）
- `PRIOR_ART_REPORT_JA.md`：文献と新規性の検討・未確認事項
- `PROOF_AUDIT_EN.md`：**v0.1と完全同一**の数学監査原本（古い状態表示はスナップショット）
- `code/` と `evidence/`：**v0.1と完全同一**
- `run_windows.ps1`：**v0.1と完全同一**（簡易ローカル検証、v0.1.2実機検証スクリプトとは別）
- `STATUS.txt`：v0.2最新版の判定
- `AUDIT_STATUS_v02_JA.md`：独立AI監査・Windows再現の報告に基づく整理
- `CHANGELOG_v02.md`：変更・不変ファイル・出所ZIP SHA256
- `SHA256SUMS.txt`：このv0.2パッケージ中の自己以外の全ファイルをSHA256で記録

## 実行・監査

Windows PowerShell 5.1（パッケージの直下で）：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_windows.ps1
```

数値テスト（既にライブラリがある場合）：

```powershell
py -3.10 -B code\verify_no55.py --milp
py -3.10 -B code\audit_atlas.py
```

ユーザーの2026-11-05 Windows実機ログでは、別提供の `No55_Run_Windows_v012.ps1` により元v0.1 ZIPのハッシュ／16 MILP例／33 Atlas例／40 Set Cover例（うち11合成）／再ハッシュがPASSした。**v0.2 ZIPそのもののWindows実機PASSとは表記しない。**

元v0.1 ZIP SHA256:

`59cfc977ac12c7bcc199e23824381bc51410a9c74c6902cab1d13752727893e8`

## 採用判定

これは**次工程（②差分監査）の入力**である。監査の実施前にv0.2の変更をPASSと断定しない。**RELEASE HOLD**。
