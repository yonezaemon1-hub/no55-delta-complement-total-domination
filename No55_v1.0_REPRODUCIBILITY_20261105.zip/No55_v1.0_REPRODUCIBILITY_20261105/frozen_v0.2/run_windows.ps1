# No.55 Windows PowerShell 5.1 local audit, fail-closed, no network/services.
param([switch]$WithMilp)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifest = Join-Path $root 'SHA256SUMS.txt'
if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw 'Missing SHA256 manifest' }
$lines = @(Get-Content -LiteralPath $manifest -Encoding UTF8)
if ($lines.Count -lt 6) { throw 'Manifest incomplete' }
foreach ($line in $lines) {
  if ($line -match '^([0-9a-f]{64})  ([A-Za-z0-9_./-]+)$') {
    $expected = $Matches[1]
    $relative = $Matches[2]
  } else { throw "Malformed manifest line: $line" }
  if ($relative.Contains('..') -or $relative.StartsWith('/') -or $relative.Contains(':')) { throw 'Unsafe path in manifest' }
  $full = Join-Path $root $relative
  if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw "Missing file $relative" }
  $actual = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -ne $expected) { throw "SHA256 FAIL: $relative" }
}
$allowed = @('SHA256SUMS.txt') + @($lines | ForEach-Object { if ($_ -match '^[0-9a-f]{64}  ([A-Za-z0-9_./-]+)$') { $Matches[1] } })
$found = @(Get-ChildItem -LiteralPath $root -File -Recurse | ForEach-Object { $_.FullName.Substring($root.Length + 1).Replace('\', '/') })
$diff = @($found | Where-Object { $allowed -notcontains $_ })
if ($diff.Count -gt 0) { throw "Unexpected files in package: $($diff -join ', ')" }
Write-Host "PASS: $($lines.Count) SHA256 hashes and exact inventory"
$cmd = Get-Command py -ErrorAction SilentlyContinue
if ($null -ne $cmd) {
  $runner = $cmd.Source
  $arglist = @('-3', '-B', (Join-Path $root 'code\verify_no55.py'))
} else {
  $cmd2 = Get-Command python -ErrorAction SilentlyContinue
  if ($null -eq $cmd2) { throw 'Python 3 unavailable' }
  $runner = $cmd2.Source
  $arglist = @('-B', (Join-Path $root 'code\verify_no55.py'))
}
if ($WithMilp) { $arglist += '--milp' }
& $runner @arglist
if ($LASTEXITCODE -ne 0) { throw "REPRO FAIL: Python exit $LASTEXITCODE" }
Write-Host 'PASS: No.55 internal self-check; NOVELTY INCONCLUSIVE; RELEASE HOLD'
