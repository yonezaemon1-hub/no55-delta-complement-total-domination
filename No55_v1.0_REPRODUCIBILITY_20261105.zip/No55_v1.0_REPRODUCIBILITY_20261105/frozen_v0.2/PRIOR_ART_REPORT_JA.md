# No.55 v0.2 — 先行研究・書誌照合記録（2026-11-05）

**状態:** REFERENCES = PARTIAL（主要項目は書誌確認） / NOVELTY = INCONCLUSIVE / RELEASE HOLD。

## 主張の区別

1. **既知:** δ補グラフの定義（Paiほか、2022）。
2. **既知:** 普通の支配数に関するδ補グラフ上界（Tangjaiほか、2026）。
3. **既知の未解決問題:** 全域支配数の和についてのChenのConjecture 4（2026）。
4. **No.55の主張:** 任意の孤立点なしグラフQについて `gamma_t(F(Q)_delta)=2m+gamma_t(Q)` と `gamma_t(F(Q))=3m`。
5. **No.55の系:** 「入力Gが二部」の場合のδ-TDS判定問題NP完全性、木に対する別の強化不等式の無限反例族。**ChenのConjecture 4の反例ではない。**

## 書誌資料と一次資料

| 対象 | 書誌 | 確認範囲・留保 |
|---|---|---|
| Paiほか (2022) | *Mathematics* 10(8), 1203, DOI `10.3390/math10081203` | 出版社公開ページで定義・著者・刊行日を確認。|
| Tangjaiほか (2026) | *Mathematics* 14(4), 734, DOI `10.3390/math14040734` | 出版社公開ページで著者・書誌・普通の支配数を対象とする要旨を確認。|
| Chen (2026) | *Mathematics* 14(11), 1797, DOI `10.3390/math14111797` | 出版社検索取得本文の§2付近で `k(G)` が異なる次数の個数、Conjecture 4 が `gamma_t(G)+gamma_t(G_delta)<=n+2k` と確認。再取得の一部は429制限あり。|
| Karp (1972) | “Reducibility Among Combinatorial Problems,” pp.85–103, DOI `10.1007/978-1-4684-2001-2_9` | DBLP書誌とSet Coverの歴史的NP完全性の引用を確認。本文の全ページ精読ではない。|
| Pfaff–Laskar–Hedetniemi (1983) | Clemson Technical Report No.428 | 二次的書誌・引用情報に基づく。原報告全文は未確認。証明の依存から除外。|
| Laskarほか (1984) | *SIAM J. Alg. Disc. Meth.* 5(3), 420–425, DOI `10.1137/0605040` | 公開要旨はundirected path graphsについて述べる。二部入力NP完全性の直接証拠として引用しない。|
| Shalu–Kirubakaran (2025) | *J. Comb. Optim.* 50, article 44, DOI `10.1007/s10878-025-01360-w` | 書誌と公開要旨で二部グラフ部分クラスのNP完全性を確認。全文比較は未実施。|

## v0.2で追加した独立還元

Set Coverの要素頂点 `e_j` と集合頂点 `s_i` に加えて、`p,r,z,q` を作る二部グラフBを定義する。辺は `s_i-e_j`（包含関係）、`s_i-z`、`p-z`、`p-q`、`r-z`。葉qとrがそれぞれpとzを選択強制し、要素を全域支配するには選んだ集合が被覆する必要がある。

よって `gamma_t(B)=tau+2`。No.55の主定理と合成して `gamma_t(F(B)_delta)=2|V(B)|+tau+2`。これにより2025年の二部TDS論文および1983年の技術報告の厳密な定理を**前提とせず**NP完全性を証明する。

**入力**の `F(B)` が二部グラフ。`F(B)_delta` が二部グラフとは主張しない。元の主定理・数値証拠はv0.1から凍結。

## 先行性判定

上記の論文と公開ページで確認した限り、主等式および「δ補グラフ入力側が二部のNP完全性」へ直接一致する明記は未発見。ただし、異なる用語のガジェット、広範な計算複雑性の既存還元、全文未確認文献、索引外資料について未調査部分がある。**直接一致が見つからないことは新規性の証明ではない。**

**RELEASE: HOLD / NOVELTY: INCONCLUSIVE / HUMAN PEER REVIEW: NOT DONE.**

## 出版元・書誌URL

- https://doi.org/10.3390/math10081203
- https://doi.org/10.3390/math14040734
- https://doi.org/10.3390/math14111797
- https://doi.org/10.1007/978-1-4684-2001-2_9
- https://doi.org/10.1137/0605040
- https://doi.org/10.1007/s10878-025-01360-w
