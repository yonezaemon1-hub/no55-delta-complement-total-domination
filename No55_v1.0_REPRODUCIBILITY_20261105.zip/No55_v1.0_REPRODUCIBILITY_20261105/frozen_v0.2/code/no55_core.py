"""No.55 exact embedding construction; standard library only; 2026-11-05.

Graph representation: dictionary mapping node labels to sets of neighbor labels.
No external services, deterministic, fail-closed on invalid input.
"""
from itertools import combinations


def make_graph(n, edges):
    if type(n) is not int or n < 2:
        raise ValueError('Input Q must contain at least two vertices.')
    adj = {str(i): set() for i in range(n)}
    for u, v in edges:
        u, v = str(u), str(v)
        if u not in adj or v not in adj or u == v:
            raise ValueError('Invalid simple-graph edge')
        adj[u].add(v)
        adj[v].add(u)
    if any(not a for a in adj.values()):
        raise ValueError('Q must have no isolated vertices')
    return adj


def add_edge(adj, a, b):
    if a == b:
        raise ValueError('Loop')
    adj.setdefault(a, set()).add(b)
    adj.setdefault(b, set()).add(a)


def chosen_degree_values(Q):
    """Small distinct target degrees meeting d_v >= deg_Q(v)+2."""
    values = {}
    last = 2
    for v in sorted(Q, key=lambda u: (len(Q[u]), int(u))):
        last = max(last + 1, len(Q[v]) + 2)
        values[v] = last
    return values


def construct(Q, degree_values=None):
    """Construct F(Q): c_v,x_v,y_v of equal degree d_v; leaves fill deficits."""
    if len(Q) < 2 or any(len(nbrs) == 0 for nbrs in Q.values()):
        raise ValueError('Q must be isolate-free')
    degrees = degree_values if degree_values is not None else chosen_degree_values(Q)
    if set(degrees) != set(Q) or len(set(degrees.values())) != len(Q):
        raise ValueError('Target degrees must be defined and pairwise distinct')
    for v in Q:
        if degrees[v] < max(3, len(Q[v]) + 2):
            raise ValueError('Target degree too small')
    G = {}
    for v in sorted(Q, key=int):
        c, x, y = (f'c_{v}', f'x_{v}', f'y_{v}')
        add_edge(G, c, x)
        add_edge(G, c, y)
        for parent, count in ((x, degrees[v] - 1), (y, degrees[v] - 1),
                              (c, degrees[v] - 2 - len(Q[v]))):
            for j in range(count):
                add_edge(G, parent, f'leaf_{parent}_{j}')
    for u in sorted(Q, key=int):
        for v in Q[u]:
            if int(u) < int(v):
                add_edge(G, f'c_{u}', f'c_{v}')
    assert all(len(G[f'{role}_{v}']) == degrees[v]
               for v in Q for role in ('c','x','y'))
    return G, degrees


def delta_complement(G):
    """Complement within original-degree classes; preserve other edges."""
    H = {u: set() for u in G}
    nodes = sorted(G)
    degrees = {u: len(G[u]) for u in nodes}
    for i, u in enumerate(nodes):
        for v in nodes[i+1:]:
            existing = (v in G[u])
            new_edge = (not existing) if degrees[u] == degrees[v] else existing
            if new_edge:
                add_edge(H, u, v)
    return H


def is_total_dominating(G, selected):
    S = set(selected)
    return S.issubset(G) and all(bool(neighbors & S) for neighbors in G.values())


def exact_total_dom_bruteforce(G, max_vertices=21):
    """Exact subset enumeration, only for small graphs."""
    n = len(G)
    if n > max_vertices:
        raise ValueError(f'{n} exceeds brute-force cap {max_vertices}')
    if any(not neighbors for neighbors in G.values()):
        raise ValueError('No total domination with isolated vertices')
    nodes = sorted(G)
    for k in range(2, n+1):
        for C in combinations(nodes, k):
            if is_total_dominating(G, C):
                return k, list(C)
    raise AssertionError('No total dominating set')


def upper_witness(Q, G):
    """Explicit TDS of F(Q)_delta of size 2m+gamma_t(Q)."""
    value, C = exact_total_dom_bruteforce(Q, max_vertices=16)
    verts = sorted(Q, key=int)
    v0 = verts[0]
    selected = []
    for v in verts:
        if v == v0:
            selected.extend((f'leaf_x_{v}_0', f'leaf_y_{v}_0'))
        else:
            selected.extend((f'x_{v}', f'y_{v}'))
    selected.extend(f'c_{v}' for v in C)
    assert len(set(selected)) == 2*len(Q)+value
    assert all(u in G for u in selected)
    return selected, value


def original_witness(Q):
    return [f'{role}_{v}' for v in sorted(Q, key=int)
            for role in ('c','x','y')]


def graph_properties(Q, G, H, deg):
    n = len(Q)
    assert len(deg) == n
    assert all(len(G[f'{role}_{v}']) == deg[v]
               for v in Q for role in ('c','x','y'))
    leaves = {u for u in G if u.startswith('leaf_')}
    assert all(len(G[u]) == 1 for u in leaves)
    for v in Q:
        assert f'y_{v}' in H[f'x_{v}']
        assert f'c_{v}' not in H[f'x_{v}']
        assert f'c_{v}' not in H[f'y_{v}']
        assert set(H[f'c_{v}']) & {f'c_{u}' for u in Q} == {f'c_{u}' for u in Q[v]}
    for leaf in leaves:
        assert leaves - {leaf} <= H[leaf]
    assert all(H[u] for u in H)
    return {'vertices':len(G), 'edges':sum(map(len,G.values()))//2,
            'leaf_count':len(leaves),'degree_classes':len(set(map(len,G.values())))}
