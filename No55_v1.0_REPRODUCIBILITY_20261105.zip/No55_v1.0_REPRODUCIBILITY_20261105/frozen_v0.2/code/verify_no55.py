"""No.55 self-check; standard library; optional SciPy MILP exact independent check."""
import argparse
import json
import platform
from pathlib import Path
from no55_core import (make_graph, construct, delta_complement, exact_total_dom_bruteforce,
                       upper_witness, original_witness, graph_properties, is_total_dominating)


def exact_total_dom_milp(G):
    from scipy.optimize import milp, Bounds, LinearConstraint
    from scipy.sparse import lil_matrix
    import numpy as np
    nodes = sorted(G); n = len(nodes)
    idx = {v:i for i,v in enumerate(nodes)}
    A = lil_matrix((n,n), dtype=float)
    for u in nodes:
        for v in G[u]:
            A[idx[u],idx[v]]=1.0
    r = milp(c=np.ones(n), integrality=np.ones(n),
             bounds=Bounds(np.zeros(n),np.ones(n)),
             constraints=LinearConstraint(A.tocsr(),np.ones(n),np.full(n,np.inf)),
             options={'mip_rel_gap':0.0,'time_limit':45})
    if not r.success or r.status != 0 or r.mip_gap is None or r.mip_gap > 1e-7:
        raise AssertionError('MILP failed to certify optimality: '+str(r.message))
    selected={nodes[i] for i,t in enumerate(r.x) if t >= 0.5}
    assert is_total_dominating(G,selected)
    assert abs(r.fun-len(selected)) < 1e-6
    return len(selected)


def sample_graphs():
    for m in range(2,9):
        yield f'path_{m}', make_graph(m,[(i,i+1) for i in range(m-1)])
    for m in range(4,8):
        yield f'star_{m}', make_graph(m,[(0,i) for i in range(1,m)])
    yield 'cycle_4', make_graph(4,[(0,1),(1,2),(2,3),(3,0)])
    yield 'complete_4', make_graph(4,[(i,j) for i in range(4) for j in range(i+1,4)])
    yield '2K2', make_graph(4,[(0,1),(2,3)])
    yield 'P3_plus_K2', make_graph(5,[(0,1),(1,2),(3,4)])
    yield 'branch_tree_7', make_graph(7,[(0,1),(0,2),(1,3),(1,4),(2,5),(2,6)])


def check(name,Q,do_milp):
    F, d=construct(Q)
    H=delta_complement(F)
    shape=graph_properties(Q,F,H,d)
    sQ,_=exact_total_dom_bruteforce(Q)
    W,checkQ=upper_witness(Q,F)
    assert checkQ == sQ
    assert is_total_dominating(H,W)
    W0=original_witness(Q)
    assert is_total_dominating(F,W0)
    assert len(W0)==3*len(Q)
    if len(Q)==2 and len(F)<=21:
        bF,_=exact_total_dom_bruteforce(F)
        bH,_=exact_total_dom_bruteforce(H)
        assert bF==3*len(Q) and bH==2*len(Q)+sQ
    if do_milp:
        mF=exact_total_dom_milp(F)
        mH=exact_total_dom_milp(H)
        assert mF==3*len(Q), (name,'original',mF)
        assert mH==2*len(Q)+sQ,(name,'delta',mH)
    return {'name':name,'m':len(Q),'nF':len(F),'kF':shape['degree_classes'],
            'gammaQ':sQ,'expected_gammaF':3*len(Q),
            'expected_gammaDeltaF':2*len(Q)+sQ,
            'witness_verified':True,'bruteforce_verified':len(Q)==2 and len(F)<=21,
            'milp_verified':do_milp,'degree_values':list(d.values())}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--milp',action='store_true',help='Use SciPy HiGHS for independent exact optimisation')
    ap.add_argument('--output',default=None,help='JSON output filepath')
    args=ap.parse_args()
    results=[]
    for name,Q in sample_graphs():
        r=check(name,Q,args.milp)
        results.append(r)
        print(f"PASS {name:17s} m={r['m']} nF={r['nF']} k={r['kF']} gammaQ={r['gammaQ']} gammaF={r['expected_gammaF']} gammaDeltaF={r['expected_gammaDeltaF']} MILP={'YES' if args.milp else 'NO'}",flush=True)
    report={'status':'PASS','date':'2026-11-05','python':platform.python_version(),
            'milp':args.milp,'case_count':len(results),'cases':results}
    if args.output:
        Path(args.output).write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print('PASS: '+str(len(results))+' constructions verified; complete theorem proof requires mathematical audit')

if __name__=='__main__': main()
