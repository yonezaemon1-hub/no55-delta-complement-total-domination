"""Optional exhaustive nonisomorphic-input audit, orders 2..5; needs networkx, scipy, numpy."""
import json
from pathlib import Path
import networkx as nx
from no55_core import make_graph, construct, delta_complement
from verify_no55 import check

def main():
    found=[]
    counts={}
    for atlas_id,g in enumerate(nx.graph_atlas_g()):
        n=g.number_of_nodes()
        if not 2 <= n <= 5 or any(v==0 for _,v in g.degree()):
            continue
        Q=make_graph(n,list(g.edges()))
        name=f'atlas_{atlas_id}'
        r=check(name,Q,True)
        F,_ = construct(Q)
        H = delta_complement(F)
        nxF=nx.Graph()
        nxF.add_nodes_from(F)
        nxF.add_edges_from((u,v) for u in F for v in F[u] if u<v)
        nxH=nx.Graph()
        nxH.add_nodes_from(F)
        for i,u in enumerate(F):
            for v in list(F)[i+1:]:
                iff=nxF.has_edge(u,v)
                toggle=nxF.degree(u)==nxF.degree(v)
                if (not iff) if toggle else iff:
                    nxH.add_edge(u,v)
        assert {frozenset((u,v)) for u in H for v in H[u]} == {frozenset(e) for e in nxH.edges()}
        assert nx.is_bipartite(nxF) == nx.is_bipartite(g)
        assert nx.is_tree(nxF) == nx.is_tree(g)
        found.append(r)
        counts[n]=counts.get(n,0)+1
        print('PASS',name,'vertices',n,'constructed',r['nF'],flush=True)
    report={'status':'PASS','source':'NetworkX graph_atlas_g, nonisomorphic graphs on 2..5 vertices without isolated vertices',
            'count':len(found),'by_input_order':counts,'cases':found}
    p=Path(__file__).resolve().parents[1]/'evidence'/'atlas_results.json'
    p.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print('PASS atlas count',len(found),'by order',counts)

if __name__=='__main__':main()
