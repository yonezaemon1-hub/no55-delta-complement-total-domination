# No.55 v1.0 - Publication status and provenance

Author: Ryutaro Yonezu - Independent Researcher
Date: 2026-11-05 JST
License: All rights reserved
Type: Preprint
Novelty: INCONCLUSIVE
Human peer review: Not done
Independent AI audit: PASS within the audited scope (user-provided reports)
Author permission: formal GitHub and Zenodo publication explicitly authorized on 2026-11-05.

## Audit scope and historical records

The user-provided independent AI audit covered the v0.1 mathematics and direct Set Cover addendum; the subsequent v0.2 documentation-only differential audit was reported PASS. The supplied final-check record records this attribution and its own limited rechecks. The full independent auditor transcript is not part of the supplied handoff and is not claimed to be included. This publication workflow checks file identity and editorial differences; it does not create a new independent mathematical audit.

All fourteen v0.2 files remain unchanged in frozen_v0.2/. Seven frozen v0.1 files - PROOF_AUDIT_EN.md, three code files, two evidence JSON files and run_windows.ps1 - remain byte-identical. Original source ZIPs are preserved in original_archives/. Old external-review, differential-audit and HOLD labels remain historical snapshots, not the current author authorization. The v1.0 manuscript is the primary public proof.

## Original Windows transcript

The user directly supplied No55_WINDOWS_LOG.txt after the publication workflow stopped for its absence. It is preserved byte-for-byte in windows/No55_WINDOWS_LOG.txt. Source path in the transcript: C:\Users\meteo\Downloads\No55_WINDOWS_REPRO_20261105_141113_795\No55_WINDOWS_LOG.txt. Timestamp: 2026-11-05 14:11:13-14:11:20 JST. This is a user-supplied original transcript, not a reconstruction or an execution performed by Work.

The transcript records Windows 10, PowerShell 5.1, Python 3.10.11, NumPy 2.2.6, SciPy 1.15.3 and NetworkX 3.4.2. It reports 16 sample MILP cases, 33 Atlas cases, 40 Set Cover cases and 11 composed F(B) cases PASS, and unchanged original v0.1 ZIP SHA256 before/after. It does not establish Windows execution of v0.2 or v1.0. No such execution is claimed.

The executable hotfix No55_Run_Windows_v012.ps1 is distinct from frozen_v0.2/run_windows.ps1. It is preserved from the supplied hotfix ZIP. No55_SetCover_Windows_Audit_v01.py is a literal extraction of the embedded Python here-string, with a terminal LF, not a newly invented verification program. The Windows-produced sample/Atlas/Set Cover JSON outputs were not supplied separately and are not claimed to be included.

Transcript SHA256: cfe7a020f2c2eb4aa0d0e8a90d835719392b9955f55c053db6a3dfb96c4db62a

## Claim boundaries

For isolate-free finite simple Q with m >= 2: gamma_t(F(Q))=3m; gamma_t(F(Q)_delta)=2m+gamma_t(Q); k(F(Q))=m+1. Bipartiteness is a property of the input F(Q); F(Q)_delta need not be bipartite. Chen's original sum conjecture is neither proved nor refuted here.

REFERENCES: PARTIAL; principal publisher metadata and public portions checked, 1983 technical report full text not inspected. NOVELTY: INCONCLUSIVE. Scholar/OpenAlex indexing: NOT CHECKED.

## Publication tracking

This immutable bundle is prepared for authorized publication. It does not itself certify that an external upload completed. The separately maintained publication receipt records actual GitHub/Zenodo URLs, DOI, public download hash checks and Drive updates. Historical HOLD files are not overwritten.
